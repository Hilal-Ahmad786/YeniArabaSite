import { Metadata } from 'next';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import FloatingButtons from '@/components/layout/FloatingButtons';
import { getServiceBySlug } from '@/data/services';
import { formatPhoneHref, formatWhatsAppHref } from '@/lib/utils';
import { siteConfig } from '@/data/site';

const service = getServiceBySlug('kazali-arac-alim');

export const metadata: Metadata = {
  title: service?.metaTitle || 'Kazalı Araç Alımı',
  description: service?.metaDescription || '',
  keywords: service?.keywords || [],
};

export default function KazaliAracPage() {
  if (!service) {
    return <div>Service not found</div>;
  }

  return (
    <>
      <Header />
      <main>
        {/* Hero Section */}
        <section className="hero-gradient text-white py-20">
          <div className="container">
            <div className="max-w-4xl mx-auto text-center">
              <div className="inline-block mb-6">
                <span className="badge bg-accent/20 text-white border border-white/30">
                  {service.hero.badge}
                </span>
              </div>
              <h1 className="text-4xl md:text-6xl font-black mb-6">
                {service.hero.title}
                <br />
                <span className="text-accent-400">{service.hero.titleHighlight}</span>
              </h1>
              <p className="text-xl text-white/90 mb-8">
                {service.hero.subtitle}
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <a href={formatPhoneHref(siteConfig.phone)} className="btn btn-primary btn-lg">
                  📞 Hemen Ara
                </a>
                <a 
                  href={formatWhatsAppHref(siteConfig.whatsapp)} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="btn btn-secondary btn-lg"
                >
                  💬 WhatsApp
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="section bg-white">
          <div className="container">
            <h2 className="text-3xl font-black text-center mb-12">Neden Bizi Seçmelisiniz?</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {service.features.map((feature, index) => (
                <div key={index} className="card">
                  <div className="text-4xl mb-3">{feature.icon}</div>
                  <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                  <p className="text-primary-600">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="section bg-primary-50">
          <div className="container max-w-4xl">
            <div className="prose prose-lg max-w-none">
              <p className="text-lg text-primary-700 mb-6">{service.content.intro}</p>
              
              <h3 className="text-2xl font-bold text-primary-900 mb-4">Hizmet Detayları</h3>
              <ul className="space-y-2 mb-8">
                {service.content.details.map((detail, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="text-accent text-xl mt-1">✓</span>
                    <span className="text-primary-700">{detail}</span>
                  </li>
                ))}
              </ul>

              <h3 className="text-2xl font-bold text-primary-900 mb-4">Neden Biz?</h3>
              <ul className="space-y-2">
                {service.content.whyUs.map((reason, index) => (
                  <li key={index} className="flex items-start gap-3">
                    <span className="text-accent text-xl mt-1">✓</span>
                    <span className="text-primary-700">{reason}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <section className="section bg-white">
          <div className="container max-w-4xl">
            <h2 className="text-3xl font-black text-center mb-12">Sıkça Sorulan Sorular</h2>
            <div className="space-y-4">
              {service.faqs.map((faq, index) => (
                <div key={index} className="card">
                  <h3 className="text-lg font-bold text-primary-900 mb-2">{faq.question}</h3>
                  <p className="text-primary-600">{faq.answer}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Final CTA */}
        <section className="section bg-gradient-to-br from-primary-800 via-secondary-800 to-secondary-900 text-white">
          <div className="container max-w-3xl text-center">
            <h2 className="text-4xl font-black mb-4">Hemen Başlayın!</h2>
            <p className="text-xl mb-8">30 dakika içinde teklif alın, anında nakit ödeme</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a href={formatPhoneHref(siteConfig.phone)} className="btn btn-primary btn-lg">
                📞 {siteConfig.phoneDisplay}
              </a>
              <a 
                href={formatWhatsAppHref(siteConfig.whatsapp)} 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn btn-secondary btn-lg"
              >
                💬 WhatsApp ile Yaz
              </a>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <FloatingButtons />
    </>
  );
}
