'use client';

import { formatPhoneHref, formatWhatsAppHref } from '@/lib/utils';
import { trackPhoneClick, trackWhatsAppClick } from '@/lib/analytics';
import { siteConfig } from '@/data/site';

export default function FloatingButtons() {
  return (
    <>
      {/* Desktop Floating Buttons */}
      <div className="hidden md:flex fixed bottom-8 right-8 flex-col gap-4 z-40">
        <a
          href={formatWhatsAppHref(siteConfig.whatsapp)}
          onClick={() => trackWhatsAppClick('floating')}
          target="_blank"
          rel="noopener noreferrer"
          className="bg-success text-white w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
          aria-label="WhatsApp"
        >
          <span className="text-2xl">💬</span>
        </a>
        <a
          href={formatPhoneHref(siteConfig.phone)}
          onClick={() => trackPhoneClick('floating')}
          className="bg-accent text-white w-14 h-14 rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform floating"
          aria-label="Telefon"
        >
          <span className="text-2xl">📞</span>
        </a>
      </div>

      {/* Mobile Bottom Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white shadow-lg border-t-2 border-accent z-50">
        <div className="flex">
          <a
            href={formatPhoneHref(siteConfig.phone)}
            onClick={() => trackPhoneClick('mobile-bottom')}
            className="flex-1 flex flex-col items-center justify-center py-3 bg-accent text-white"
          >
            <span className="text-2xl mb-1">📞</span>
            <span className="text-xs font-semibold">Hemen Ara</span>
          </a>
          <a
            href={formatWhatsAppHref(siteConfig.whatsapp)}
            onClick={() => trackWhatsAppClick('mobile-bottom')}
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 flex flex-col items-center justify-center py-3 bg-success text-white"
          >
            <span className="text-2xl mb-1">💬</span>
            <span className="text-xs font-semibold">WhatsApp</span>
          </a>
        </div>
      </div>

      {/* Add padding to body to prevent content from being hidden behind mobile bottom bar */}
      <div className="md:hidden h-20" />
    </>
  );
}
