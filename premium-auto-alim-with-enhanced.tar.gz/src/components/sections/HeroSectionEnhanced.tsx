'use client';

import { useState } from 'react';
import { siteConfig, stats } from '@/data/site';
import { formatPhoneHref, formatWhatsAppHref } from '@/lib/utils';
import { trackPhoneClick, trackWhatsAppClick, trackFormSubmit } from '@/lib/analytics';

export default function HeroSectionEnhanced() {
  const [formData, setFormData] = useState({
    vehicleType: 'kazali-arac',
    phone: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    trackFormSubmit('hero-form');
    alert('Form gönderildi! Kısa sürede sizi arayacağız.');
  };

  return (
    <section className="hero-gradient text-white py-20 relative overflow-hidden">
      {/* Background Patterns */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-20 w-64 h-64 bg-accent rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-secondary-600 rounded-full blur-3xl"></div>
      </div>

      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div>
            <div className="inline-block mb-6">
              <span className="badge bg-accent/20 text-white border border-white/30 text-sm">
                🚗 TÜRKİYE'NİN EN GÜVENİLİR PLATFORMU
              </span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-black mb-6 leading-tight">
              Hasarlı Aracınızı
              <br />
              <span className="text-accent-400">En İyi Fiyata</span> Satın
            </h1>
            
            <p className="text-xl text-white/90 mb-8">
              30 dakikada teklif, aynı gün nakit. Ücretsiz ekspertiz ve çekici hizmeti ile güvenle satın.
            </p>

            {/* Feature Badges */}
            <div className="flex flex-wrap gap-3 mb-8">
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                <span className="text-xl">⚡</span>
                <span className="text-sm font-semibold">30 Dakika Teklif</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                <span className="text-xl">💰</span>
                <span className="text-sm font-semibold">En Yüksek Fiyat</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                <span className="text-xl">✅</span>
                <span className="text-sm font-semibold">Ücretsiz Hizmet</span>
              </div>
              <div className="flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2">
                <span className="text-xl">📋</span>
                <span className="text-sm font-semibold">Anında Ödeme</span>
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 mb-8">
              <a
                href={formatWhatsAppHref(siteConfig.whatsapp)}
                onClick={() => trackWhatsAppClick('hero')}
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-lg bg-success hover:bg-success/90 text-white border-0"
              >
                💬 WhatsApp ile Teklif Al
              </a>
              <a
                href={formatPhoneHref(siteConfig.phone)}
                onClick={() => trackPhoneClick('hero')}
                className="btn btn-lg btn-outline text-white border-white hover:bg-white hover:text-primary-800"
              >
                📞 Hemen Ara
              </a>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-6 border-t border-white/20">
              <div>
                <div className="text-3xl font-black text-accent-400">{stats[0].value}</div>
                <div className="text-sm text-white/70">{stats[0].label}</div>
              </div>
              <div>
                <div className="text-3xl font-black text-accent-400">{stats[2].value}</div>
                <div className="text-sm text-white/70">{stats[2].label}</div>
              </div>
              <div>
                <div className="text-3xl font-black text-accent-400">{stats[3].value}</div>
                <div className="text-sm text-white/70">{stats[3].label}</div>
              </div>
            </div>
          </div>

          {/* Right Content - Contact Form Card */}
          <div className="relative">
            <div className="bg-white rounded-2xl shadow-2xl p-8">
              <div className="flex items-center justify-center w-16 h-16 bg-accent rounded-full mb-4 mx-auto">
                <span className="text-3xl">📞</span>
              </div>
              
              <h3 className="text-2xl font-black text-center text-secondary-900 mb-2">
                Hemen Teklif Alın
              </h3>
              <p className="text-center text-secondary-600 mb-6">
                Hasarlı Araç Alımı için özel fiyat teklifi alın
              </p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-secondary-700 mb-2">
                    Araç Tipi
                  </label>
                  <select
                    value={formData.vehicleType}
                    onChange={(e) => setFormData({...formData, vehicleType: e.target.value})}
                    className="w-full px-4 py-3 border-2 border-primary-200 rounded-lg focus:outline-none focus:border-primary text-secondary-900"
                  >
                    <option value="kazali-arac">Kazalı Araç</option>
                    <option value="hasarli-arac">Hasarlı Araç</option>
                    <option value="pert-arac">Pert Araç</option>
                    <option value="hurda-arac">Hurda Araç</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-secondary-700 mb-2">
                    Telefon Numaranız
                  </label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                    placeholder="0555 123 45 67"
                    className="w-full px-4 py-3 border-2 border-primary-200 rounded-lg focus:outline-none focus:border-primary text-secondary-900"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full btn btn-lg bg-accent hover:bg-accent-600 text-white border-0"
                >
                  Ücretsiz Teklif Al
                </button>

                <p className="text-xs text-center text-secondary-500 flex items-center justify-center gap-2">
                  <span>🔒</span>
                  <span>SSL Güvenli • KVKK Uyumlu • Güvenli İletişim</span>
                </p>
              </form>

              {/* Quick Stats */}
              <div className="mt-6 pt-6 border-t border-secondary-100">
                <div className="text-center">
                  <p className="text-sm font-semibold text-secondary-700 mb-3">Bu Hizmet İçin</p>
                  <div className="grid grid-cols-3 gap-3">
                    <div className="text-center">
                      <div className="text-xl font-black text-accent">24 saat</div>
                      <div className="text-xs text-secondary-600">İşlem Süresi</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-black text-accent">5000+</div>
                      <div className="text-xs text-secondary-600">Müşteri Sayısı</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xl font-black text-accent">%98</div>
                      <div className="text-xs text-secondary-600">Memnuniyet</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Floating Trust Badge */}
            <div className="absolute -bottom-4 -left-4 bg-success text-white rounded-full p-4 shadow-lg">
              <div className="flex items-center gap-2">
                <span className="text-2xl">✓</span>
                <div className="text-xs font-bold">
                  <div>Güvenilir</div>
                  <div>İşlem</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
